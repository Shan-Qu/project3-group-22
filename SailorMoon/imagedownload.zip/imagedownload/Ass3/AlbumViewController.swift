//
//  AlbumViewController.swift
//  Ass3
//
//  Created by Corrina Qu on 2018/5/21.
//  Copyright © 2018年 Shan Qu. All rights reserved.
//

import UIKit

class AlbumViewController: UIViewController {

    @IBOutlet weak var image1: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //Decode
        let data = UserDefaults.standard.object(forKey: "Image1") as! NSData
        image1.image = UIImage(data: data as Data)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
