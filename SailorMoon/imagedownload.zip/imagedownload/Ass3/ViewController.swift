//
//  ViewController.swift
//  Ass3
//
//  Created by Corrina Qu on 2018/5/21.
//  Copyright © 2018年 Shan Qu. All rights reserved.
//

import UIKit

extension UIImage {
    convenience init(view: UIView) {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in:UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        self.init(cgImage: image!.cgImage!)
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    @IBAction func saveImage(_ sender: UIButton) {
        let image = UIImage(view: myView)
        
        let imageData:NSData = UIImagePNGRepresentation(image)! as NSData
        
        //Saved image
        UserDefaults.standard.set(imageData, forKey: "Image1")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

       
        
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

